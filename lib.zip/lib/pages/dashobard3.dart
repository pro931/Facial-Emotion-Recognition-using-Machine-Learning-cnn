import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;


// TimeSeriesChart
class DataPoint {
  final DateTime date;
  final double ratio;
  final String emotion;

  DataPoint(this.date, this.ratio, this.emotion);
}

enum TimeFilter {
  day,
  weak,
  month,
  year,
}

enum EmotionFilter {
  angry,
  disgust,
  fear,
  happy,
  neutral,
  sad,
  surprise,
}

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<DataPoint> data = [
    DataPoint(DateTime(2023, 1, 1), 0.8, 'Happy'),
    DataPoint(DateTime(2023, 1, 2), 0.6, 'Happy'),
    DataPoint(DateTime(2023, 1, 3), 0.2, 'Sad'),
    DataPoint(DateTime(2023, 1, 4), 0.9, 'Happy'),
    DataPoint(DateTime(2023, 1, 5), 0.3, 'Sad'),
    // Add more data points
  ];

  TimeFilter selectedTimeFilter = TimeFilter.day;
  EmotionFilter selectedEmotionFilter = EmotionFilter.happy;

  List<DataPoint> filteredData = [];

  @override
  void initState() {
    super.initState();
    filterData();
  }

  void filterData() {
    DateTime now = DateTime.now();
    filteredData = data.where((datapoint) {
      switch (selectedTimeFilter) {
        case TimeFilter.day:
          return datapoint.date.year == now.year &&
              datapoint.date.month == now.month &&
              datapoint.date.day == now.day;
        case TimeFilter.weak:
          DateTime weekAgo = now.subtract(Duration(days: 7));
          return datapoint.date.isAfter(weekAgo);
        case TimeFilter.month:
          return datapoint.date.year == now.year &&
              datapoint.date.month == now.month;
        case TimeFilter.year:
          return datapoint.date.year == now.year;
        default:
          return true;
      }
    }).toList();

    if (selectedEmotionFilter != null) {
      filteredData = filteredData
          .where((datapoint) =>
              datapoint.emotion == getEmotionName(selectedEmotionFilter))
          .toList();
    }
  }

  String getEmotionName(EmotionFilter emotionFilter) {
    switch (emotionFilter) {
      case EmotionFilter.angry:
        return 'Angry';
      case EmotionFilter.disgust:
        return 'Disgust';
      case EmotionFilter.fear:
        return 'Fear';
      case EmotionFilter.happy:
        return 'Happy';
      case EmotionFilter.neutral:
        return 'Neutral';
      case EmotionFilter.sad:
        return 'Sad';
      case EmotionFilter.surprise:
        return 'Surprise';
      default:
        return '';
    }
  }

  List<charts.Series<DataPoint, DateTime>> _createSeries() {
    return [
      charts.Series<DataPoint, DateTime>(
        id: 'Data',
        domainFn: (DataPoint datapoint, _) => datapoint.date,
        measureFn: (DataPoint datapoint, _) => datapoint.ratio,
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        data: filteredData,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Data Charts',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Data Charts'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DropdownButton<TimeFilter>(
                    value: selectedTimeFilter,
                    // onChanged: (TimeFilter newValue) {
                    onChanged: (newValue) {
                      setState(() {
                        // selectedTimeFilter = newValue;
                        filterData();
                      });
                    },
                    items: TimeFilter.values.map((TimeFilter value) {
                      return DropdownMenuItem<TimeFilter>(
                        value: value,
                        child: Text(getTimeFilterName(value)),
                      );
                    }).toList(),
                  ),
                  SizedBox(width: 20.0),
                  DropdownButton<EmotionFilter>(
                    value: selectedEmotionFilter,
                    // onChanged: (required EmotionFilter newValue) {
                    onChanged: (newValue) {
                      setState(() {
                        // selectedEmotionFilter = newValue;
                        filterData();
                      });
                    },
                    items: EmotionFilter.values.map((EmotionFilter value) {
                      return DropdownMenuItem<EmotionFilter>(
                        value: value,
                        child: Text(getEmotionFilterName(value)),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            Expanded(
              child: charts.TimeSeriesChart(
                _createSeries(),
                animate: true,
                dateTimeFactory: const charts.LocalDateTimeFactory(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String getTimeFilterName(TimeFilter timeFilter) {
  switch (timeFilter) {
    case TimeFilter.day:
      return 'day';
    case TimeFilter.weak:
      return 'weak';
    case TimeFilter.month:
      return 'month';
    case TimeFilter.year:
      return 'year';
    default:
      return '';
  }
}

String getEmotionFilterName(EmotionFilter emotionFilter) {
  switch (emotionFilter) {
    case EmotionFilter.angry:
      return 'angry';
    case EmotionFilter.disgust:
      return 'disgust';
    case EmotionFilter.fear:
      return 'fear';
    case EmotionFilter.happy:
      return 'happy';
    case EmotionFilter.neutral:
      return 'neutral';
    case EmotionFilter.sad:
      return 'sad';
    case EmotionFilter.surprise:
      return 'surprise';
    default:
      return '';
  }
}
