import 'dart:io';
import 'package:face_emotion/presentation/chart/bar.dart';
import 'package:face_emotion/presentation/chart/line.dart';
import 'package:face_emotion/presentation/chart/pie.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

//1
class DataEmotions {
  final DateTime date;
  final int count;
  final double rate;
  final String emotion;
  DataEmotions(
      {required this.date,
      required this.emotion,
      required this.rate,
      required this.count});
  // DataEmotions(this.date, this.emotion, this.rate, this.count);

  factory DataEmotions.fromJson(Map<String, dynamic> json) {
    return DataEmotions(
      date: DateTime.parse(json['date']),
      emotion: json['emotion'],
      rate: json['rate'],
      count: json['count'],
    );
  }
}

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<DataEmotions> data = [];
  @override
  void initState() {
    super.initState();
    this.getData();
  }

  static final Map<String, String> httpHeaders = {
    HttpHeaders.contentTypeHeader: "application/json",
    "Connection": "Keep-Alive",
    "Keep-Alive": "timeout=100, max=100000"
  };

  Future<List<DataEmotions>> fetchData() async {
    final response = await http.get(Uri.parse('http://10.0.2.2:5000/dashboard'), headers: httpHeaders);
    print(response);
    if (response.statusCode == 200) {
      var body = jsonDecode(response.body)['emotions'];
      final List<dynamic> jsonResponse = jsonDecode(body);
      print(jsonResponse);
      return jsonResponse
          .map((userJson) => DataEmotions.fromJson(userJson))
          .toList();
    } else {
      return [];
    }
  }

  void getData() async {
    try {
      List<DataEmotions> dddd = await fetchData();
      setState(() {
        data = dddd;
      });
      print(dddd);
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      // title: 'Data Charts',
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 34, 196, 241),
          foregroundColor: Color.fromARGB(252, 245, 238, 220),
          title: Text('Dashboard'),
          titleTextStyle: const TextStyle(
              fontSize: 25,
              fontFamily: "myfont",
              fontWeight: FontWeight.w500,
              color: Color.fromARGB(252, 245, 238, 220)),
          bottom: TabBar(
            tabs: [

              Tab(text: 'By Ratio'),
              Tab(
                text: 'By Time Series',
              ),
              Tab(
                text: 'By Emotion',
              ),
            ],
            labelColor: Color.fromARGB(255, 9, 29, 252),
            unselectedLabelColor: Colors.white,
            dividerColor: Colors.red,
            overlayColor:
                MaterialStateProperty.all(Color.fromARGB(252, 245, 238, 220)),
            labelStyle: TextStyle(
                fontSize: 15, color: Colors.white),
          ),
        ),
        body: TabBarView(
          children: [
            if (data.length > 0)
            Dashboard1(
              tabIndex: 0,
              data: data,
            ),
            if (data.length > 0)
            Dashboard2(
              tabIndex: 1,
              data: data,
            ),
            if (data.length > 0)
            Dashboard3(
              tabIndex: 2,
              data: data,
            ),
          ],
          // children: [
          //   Center(child: Text('By Ratio1'),),
          //   Center(child: Text('By Ratio2'),),
          //   Center(child: Text('By Ratio3'),),
          // ]
        ),
      ),
    );
  }
}


// enum TimeFilter {
//   day,
//   weak,
//   month,
//   year,
// }

// enum EmotionFilter {
//   Angry,
//   Disgust,
//   Fear,
//   Happy,
//   Neutral,
//   Sad,
//   Surprise,
// }


// String getTimeFilterName(TimeFilter timeFilter) {
//   switch (timeFilter) {
//     case TimeFilter.day:
//       return 'day';
//     case TimeFilter.weak:
//       return 'weak';
//     case TimeFilter.month:
//       return 'month';
//     case TimeFilter.year:
//       return 'year';
//     default:
//       return '';
//   }
// }

// String getEmotionFilterName(EmotionFilter emotionFilter) {
//   switch (emotionFilter) {
//     case EmotionFilter.Angry:
//       return 'Angry';
//     case EmotionFilter.Disgust:
//       return 'Disgust';
//     case EmotionFilter.Fear:
//       return 'Fear';
//     case EmotionFilter.Happy:
//       return 'Happy';
//     case EmotionFilter.Neutral:
//       return 'Neutral';
//     case EmotionFilter.Sad:
//       return 'Sad';
//     case EmotionFilter.Surprise:
//       return 'Surprise';
//     default:
//       return '';
//   }
// }