// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/material.dart';

class Welcome extends StatefulWidget {
  const Welcome({Key? key}) : super(key: key);

  @override
  _WelcomeState createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  bool _isHovered = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: Text(
          "Home",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/take-photo');
              },
              style: ButtonStyle(
                fixedSize: MaterialStateProperty.all(Size(300, 100)),
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
              ),
              child: Text(
                'Take Photo',
                style: TextStyle(fontSize: 25),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/select-photo');
              },
              style: ButtonStyle(
                fixedSize: MaterialStateProperty.all(Size(300, 100)),
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
              ),
              child: Text(
                'Select Photo',
                style: TextStyle(fontSize: 35),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/realtime');
              },
              style: ButtonStyle(
                fixedSize: MaterialStateProperty.all(Size(300, 100)),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
              ),
              child: Text(
                'Realtime Video',
                style: TextStyle(fontSize: 35),
              ),
            ),
            // MouseRegion(
            //   onEnter: (event) => setState(() => _isHovered = true),
            //   onExit: (event) => setState(() => _isHovered = false),
            //   child: Container(
            //     decoration: BoxDecoration(
            //       color: _isHovered ? Colors.blue : Colors.grey,
            //       borderRadius: BorderRadius.circular(5),
            //     ),
            //     child: TextButton(
            //       onPressed: () {
            //         Navigator.pushNamed(context, '/dashboard');
            //       },
            //       style: ButtonStyle(
            //         fixedSize: MaterialStateProperty.all(Size(400, 130)),
            //         backgroundColor: MaterialStateProperty.all(
            //             Color.fromARGB(255, 0, 64, 255)),
            //         padding: MaterialStateProperty.all(
            //             EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
            //         foregroundColor: MaterialStateProperty.all(
            //             Color.fromARGB(252, 245, 238, 220)),
            //         shape: MaterialStateProperty.all(RoundedRectangleBorder(
            //             borderRadius: BorderRadius.circular(49))),
            //       ),
            //       child: Text(
            //         'Dashboard',
            //         style: TextStyle(
            //           fontSize: 35,
            //         ),
            //       ),
            //     ),
            //   ),
            // ),
            
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/dashboard');
              },
              style: ButtonStyle(
                fixedSize: MaterialStateProperty.all(Size(300, 100)),
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 50, vertical: 18)),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
              ),
              child: Text(
                'Dashboard',
                style: TextStyle(
                  fontSize: 35,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/about-us');
              },
              style: ButtonStyle(
                fixedSize: MaterialStateProperty.all(Size(300, 100)),
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
              ),
              child: Text(
                'About As',
                style: TextStyle(
                  fontSize: 35,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// class Welcome extends StatelessWidget {
//   const Welcome({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.purple[300],
//         title: Text(
//           "Welcome",
//           style: TextStyle(
//               fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
//         ),
//         centerTitle: true,
//       ),
//       body: content(context),
//     );
//   }

//   Widget content(context) {
//     return SizedBox(
//       width: double.infinity,
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: [
//           ElevatedButton(
//             onPressed: () {
//               // Navigator.of(context).pushNamed('/dd');
//               Navigator.pushNamed(context, "/dd");
//             },
//             style: ButtonStyle(
//               backgroundColor: MaterialStateProperty.all(Colors.purple),
//               padding: MaterialStateProperty.all(
//                   EdgeInsets.symmetric(horizontal: 79, vertical: 10)),
//               shape: MaterialStateProperty.all(RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(49))),
//             ),
//             child: Text(
//               "login",
//               style: TextStyle(fontSize: 24),
//             ),
//           ),
//           SizedBox(
//             height: 22,
//           ),
//           ElevatedButton(
//             onPressed: () {
//               Navigator.pushNamed(context, "/signup");
//             },
//             style: ButtonStyle(
//               backgroundColor: MaterialStateProperty.all(Colors.purple[100]),
//               padding: MaterialStateProperty.all(
//                   EdgeInsets.symmetric(horizontal: 77, vertical: 13)),
//               shape: MaterialStateProperty.all(RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(49))),
//             ),
//             child: Text(
//               "SIGNUP",
//               style: TextStyle(fontSize: 17, color: Colors.grey[850]),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }














