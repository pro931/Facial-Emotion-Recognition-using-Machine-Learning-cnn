import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:io';
import 'package:http/http.dart' as http;


class RealtimeScreen extends StatefulWidget {
  @override
  RealtimeScreenState createState() => RealtimeScreenState();
}

class RealtimeScreenState extends State<RealtimeScreen> {
  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
      return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: const Color.fromARGB(252, 245, 238, 220),
        title: const Text(
          "Realtime Face Emotions",
          style: TextStyle(
              fontSize: 20, fontFamily: "myfont", fontWeight: FontWeight.w400),
        ),
        centerTitle: true,
      ),
      body: WebView(
      javascriptMode: JavascriptMode.unrestricted,
      initialUrl:'http://10.0.2.2:5000/',
    ));
  }
}