// ignore_for_file: must_be_immutable, unnecessary_new, unused_element, avoid_print, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
// import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
// import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
String url = 'http://10.0.2.2:5000/upload_image';


class TakePictureScreen extends StatefulWidget {
  const TakePictureScreen({
    super.key,
    required this.camera,
  });

  final CameraDescription camera;

  @override
  TakePictureScreenState createState() => TakePictureScreenState();
}

class TakePictureScreenState extends State<TakePictureScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  File? imageFile;
  Uint8List imageBytes = new Uint8List(0);
  final ImagePicker _picker = ImagePicker();

  Future<void> _uploadImage() async {
    try {
      final XFile? pickedFile =
          await _picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        // setState(() {
          imageFile = File(pickedFile.path);
        // });
        uploadImage(pickedFile);
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  static final Map<String, String> httpHeaders = {
    // HttpHeaders.contentTypeHeader: "application/json",
    "Connection": "Keep-Alive",
    "Keep-Alive": "timeout=100, max=100000"
  };

  Future<void> uploadImage(XFile image) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse(url));
      request.files.add(await http.MultipartFile.fromPath('image', image.path));
      request.headers.addAll(httpHeaders);
      final response = await request.send();
      if (response.statusCode == 200) {
        final img = await response.stream.toBytes();
        // setState(() {
          imageBytes = img;
        // });
      } else {
        print('Error uploading image: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = CameraController(
      widget.camera,
      ResolutionPreset.medium,
    );
    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: Text(
          "Take Photo",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CameraPreview(_controller);
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          try {
            await _initializeControllerFuture;
            final image = await _controller.takePicture();
            imageFile = File(image.path);
            await uploadImage(image);
            if (!mounted) return;
              await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => DisplayPictureScreen(
                  imageFile: imageFile,
                  imageBytes: imageBytes,
                ),
              ),
            );
          } catch (e) {
            // If an error occurs, log the error to the console.
            print(e);
          }
        },
        child: const Icon(Icons.camera_alt),
      ),
    );
  }
}

// A widget that displays the picture taken by the user.
class DisplayPictureScreen extends StatelessWidget {
  File? imageFile;
  Uint8List imageBytes = new Uint8List(0);
  DisplayPictureScreen({super.key, required this.imageFile, required this.imageBytes});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: Text(
          "Show Image Emothion",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // const SizedBox(height: 400,),
            if (imageFile != null)
              Image.file(
                imageFile!,
                height: 250,
                // width: 350,
                alignment: Alignment.topCenter,
                cacheHeight: 250,
                cacheWidth: 300,
                fit: BoxFit.fill,
              ),
            if (imageBytes.length > 0)
              Image.memory(
                Uint8List.fromList(imageBytes),
                width: 250,
                height: 250,
                cacheWidth: 300,
                alignment: Alignment.bottomCenter,
                fit: BoxFit.fill,
              ),
          ],
        ),
      ),
    );
  }
}
