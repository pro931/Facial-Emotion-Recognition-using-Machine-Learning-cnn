import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
String url = 'http://10.0.2.2:5000/upload_image';

class EmotionFromPhotoGallery extends StatefulWidget {
  const EmotionFromPhotoGallery({Key? key}) : super(key: key);

  @override
  _EmotionFromPhotoGalleryState createState() =>
      _EmotionFromPhotoGalleryState();
}

class _EmotionFromPhotoGalleryState extends State<EmotionFromPhotoGallery> {
  File? _imageFile;
  Uint8List _imageBytes = new Uint8List(0);
  final ImagePicker _picker = ImagePicker();

  Future<void> _uploadImage() async {
    try {
      final XFile? pickedFile =
          await _picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
        uploadImage(pickedFile);
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  static final Map<String, String> httpHeaders = {
    // HttpHeaders.contentTypeHeader: "application/json",
    "Connection": "Keep-Alive",
    "Keep-Alive": "timeout=100, max=100000"
  };

  Future<void> uploadImage(XFile image) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse(url));
      request.files.add(await http.MultipartFile.fromPath('image', image.path));
      request.headers.addAll(httpHeaders);
      final response = await request.send();
      if (response.statusCode == 200) {
        final img = await response.stream.toBytes();
        setState(() {
          _imageBytes = img;
        });
      } else {
        print('Error uploading image: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: const Text(
          "Select Photo From Gallery",
          style: TextStyle(
              fontSize: 25, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: _uploadImage,
              style: ButtonStyle(
                // fixedSize: MaterialStateProperty.all(Size(400, 80)),
                backgroundColor: MaterialStateProperty.all(
                    Color.fromARGB(255, 0, 64, 255)),
                padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(horizontal: 79, vertical: 22)),
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(49))),
                foregroundColor: MaterialStateProperty.all(
                    Color.fromARGB(252, 245, 238, 220)),
              ),
              child: const Text(
                'Select Image',
                style: TextStyle(fontSize: 24),
              ),
            ),
            // const SizedBox(height: 400,),
            if (_imageFile != null)
              Image.file(
                _imageFile!,
                height: 200,
                width: 300,
                alignment: Alignment.topCenter,
                cacheHeight: 300,
                cacheWidth: 300,
                fit: BoxFit.fill,
              ),
            if (_imageBytes.length > 0)
              Image.memory(
                Uint8List.fromList(_imageBytes),
                width: 350,
                height: 250,
                cacheWidth: 300,
                alignment: Alignment.bottomCenter,
                fit: BoxFit.fill,
              ),
          ],
        ),
      ),
    );
  }
}
