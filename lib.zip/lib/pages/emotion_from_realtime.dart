// ignore_for_file: unused_import, unused_local_variable, use_key_in_widget_constructors, library_private_types_in_public_api, deprecated_member_use

import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class EmotionFromVideoRealtime extends StatefulWidget {
  final CameraDescription camera;
  const EmotionFromVideoRealtime({required this.camera});

  @override
  _EmotionFromVideoRealtimeState createState() => _EmotionFromVideoRealtimeState();
}

class _EmotionFromVideoRealtimeState extends State<EmotionFromVideoRealtime> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  late VideoPlayerController _videoPlayerController;
  late Future<void> _initializeVideoPlayerFuture;
  bool _isRecording = false;
  String? _imageUrl;

  @override
  void initState() {
    super.initState();
    _controller = CameraController(
      widget.camera,
      ResolutionPreset.medium,
    );
    _initializeControllerFuture = _controller.initialize();
    _videoPlayerController = VideoPlayerController.network('');
    _initializeVideoPlayerFuture = _videoPlayerController.initialize();
  }

  Future<void> _startRecording() async {
    if (!_controller.value.isInitialized) {
      return;
    }
    setState(() {
      _isRecording = true;
    });
    final Directory appDirectory = await getApplicationDocumentsDirectory();
    final String videoDirectory = '${appDirectory.path}/Videos';
    await Directory(videoDirectory).create(recursive: true);
    final String videoPath = '$videoDirectory/${DateTime.now()}.mp4';
    // videoPath
    try {
      // await _controller.startVideoRecording(videoPath);
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> _stopRecording() async {
    if (!_controller.value.isRecordingVideo) {
      return;
    }
    setState(() {
      _isRecording = false;
    });
    try {
      await _controller.stopVideoRecording();
      await _processVideo();
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> _processVideo() async {
    // final File videoFile = File(_controller.value.videoPath!);
    // if (videoFile != null) {
    //   final bytes = await videoFile.readAsBytes();
    //   final response = await http.post(
    //     'YOUR_FLASK_API_URL' as Uri,
    //     body: bytes,
    //   );
    //   final imageUrl = response.body;
    //   setState(() {
    //     _imageUrl = imageUrl;
    //   });
    // }
  }

  @override
  void dispose() {
    _controller.dispose();
    _videoPlayerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(251, 244, 240, 230),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 196, 111, 211),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: const Text(
          "Emotion Face Realtime",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Stack(
              children: <Widget>[
                FutureBuilder<void>(
                  future: _initializeControllerFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.done) {
                      return CameraPreview(_controller);
                    } else {
                      return Center(child: CircularProgressIndicator());
                    }
                  },
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: FloatingActionButton(
                      child: Icon(_isRecording ? Icons.stop : Icons.fiber_manual_record),
                      onPressed: () {
                        if (_isRecording) {
                          _stopRecording();
                        } else {
                          _startRecording();
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_imageUrl != null)
            FutureBuilder<void>(
              future: _initializeVideoPlayerFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return AspectRatio(
                    aspectRatio: _videoPlayerController.value.aspectRatio,
                    child: VideoPlayer(_videoPlayerController),
                  );
                } else {
                  return Center(child: CircularProgressIndicator());
                }
              },
            ),
        ],
      ),
    );
  }
}