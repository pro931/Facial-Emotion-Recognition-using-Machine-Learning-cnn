import 'package:flutter/material.dart';

class Programmer {
  final String name;
  final String num;

  Programmer(this.name, this.num);
}

class AboutUs extends StatelessWidget {
  final List<Programmer> programmers = [
    Programmer('Rimas Abdulrhman', '439808955'),
    Programmer('Manar Mohamad', '441808206'),
    Programmer('Ghadi Nawaf', '442803386'),
    Programmer('', ''),
    Programmer('Supervised by: ', ''),
    Programmer('Dr. SUHAIL QADIR GH QADIR', ''),
    // Programmer('Dr. Suhail Qadir GH Qadir', ''),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 34, 196, 241),
        foregroundColor: Color.fromARGB(252, 245, 238, 220),
        title: Text(
          "About Us",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      // body: Scaffold(
        body: ListView.builder(
          itemCount: programmers.length,
          itemBuilder: (context, index) {
            return ListTile(
              titleAlignment: ListTileTitleAlignment.center,
              textColor: Colors.red,
              subtitle: Text(programmers[index].num, textAlign: TextAlign.center, style: TextStyle(
                    fontSize: 26, color: Color.fromARGB(255, 34, 196, 241), 
                  ),),
              // leading: Icon(Icons.person),
              title: Text(programmers[index].name, textAlign: TextAlign.center, style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue, 
                    
                  ),)
            );
          },
        ),
      // ),
    );
  }
}