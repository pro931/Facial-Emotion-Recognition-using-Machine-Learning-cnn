import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;


//bar
class ChartData {
  final String category;
  final int value;

  ChartData(this.category, this.value);
}

class MyChart extends StatelessWidget {
  final List<charts.Series<dynamic, String>> seriesList;
  bool animate = true;

  MyChart(this.seriesList, this.animate);

  @override
  Widget build(BuildContext context) {
    return charts.BarChart(
      seriesList,
      animate: animate,
    );
  }
}

class Dashboard extends StatelessWidget {
  // const Dashboard({Key? key}) : super(key: key);
  int selectedDay = 0;
  int selectedMonth = 0;

  @override
  Widget build(BuildContext context) {
    final List<int> days = List<int>.generate(31, (index) => index + 1);
    final List<String> months = [
      'all month', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
      'September', 'October', 'November', 'December'
    ];

    final List<ChartData> data = [
      ChartData('Category 1', 5),
      ChartData('Category 2', 10),
      ChartData('Category 3', 15),
      ChartData('Category 4', 20),
    ];

    final series = [
      charts.Series(
        id: 'Data',
        data: data,
        domainFn: (ChartData chartData, _) => chartData.category,
        measureFn: (ChartData chartData, _) => chartData.value,
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
      ),
    ];

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context);
        },
        backgroundColor: Colors.purple[400],
        child: const Icon(Icons.home),
      ),
      appBar: AppBar(
        title: const Text(
          "Dashboard",
          style: TextStyle(
              fontSize: 30, fontFamily: "myfont", fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
        backgroundColor: Colors.purple[300],
      ),
      // body: Center(
      //     child: Row(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       children: [
      //         DropdownButton<int>(
      //           value: selectedDay,
      //           hint: const Text('Day'),
      //           onChanged: () {
      //             setState(() {
      //               selectedDay = newValue;
      //             });
      //           },
      //           items: days.map<DropdownMenuItem<int>>((int value) {
      //             return DropdownMenuItem<int>(
      //               value: value,
      //               child: Text(value.toString()),
      //             );
      //           }).toList(),
      //         ),
      //         SizedBox(width: 20.0),
      //         DropdownButton<String>(
      //           value: selectedMonth,
      //           hint: Text('Month'),
      //           onChanged: (String newValue) {
      //             setState(() {
      //               selectedMonth = newValue;
      //             });
      //           },
      //           items: months.map<DropdownMenuItem<String>>((String value) {
      //             return DropdownMenuItem<String>(
      //               value: value,
      //               child: Text(value),
      //             );
      //           }).toList(),
      //         ),
      //       ],
      //     ),
      //     Row(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       children: [
      //     MyChart(
      //   series,
      //   true,
      // ),
      //     ),
      // )
    );
  }
}
