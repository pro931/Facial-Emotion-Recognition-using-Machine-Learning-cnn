import 'package:face_emotion/pages/dashboard.dart';
import 'package:face_emotion/presentation/resources/app_resources.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class Dashboard2 extends StatefulWidget {
  Dashboard2({
    Key? key,
    required this.tabIndex,
    required this.data,
  }) : super(key: key);

  final int tabIndex;
  List<DataEmotions> data = [];

  @override
  _Dashboard2State createState() => _Dashboard2State();
}

class _Dashboard2State extends State<Dashboard2> {
  List<DataEmotions> data2 = [];
  String? selectedFilter = 'This Year';
  String? selectedEmotion = 'All';
  final List<String> filtersChart = [
    'This Weak',
    'This Month',
    'This Year',
  ];
  final List<String> emotion = [
    'All',
    'Angry',
    'Disgust',
    'Fear',
    'Happy',
    'Neutral',
    'Sad',
    'Surprise',
  ];
  final List<int> days = List<int>.generate(31, (index) => index + 1);
  final List<int> months = List<int>.generate(12, (index) => index + 1);
  List<int> weeaks = List<int>.generate(7, (index) => index + 1);
  double angryVal = 0;
  double disgustVal = 0;
  double fearVal = 0;
  double happyVal = 0;
  double neutralVal = 0;
  double sadVal = 0;
  double surpriseVal = 0;
  double maxY = 8;
  double mmaxX = 13;
  double mmaxY = 15;
  List<FlSpot> spotsAngry = [];
  List<FlSpot> spotsDisgust = [];
  List<FlSpot> spotsFear = [];
  List<FlSpot> spotsHappy = [];
  List<FlSpot> spotsNeutral = [];
  List<FlSpot> spotsSad = [];
  List<FlSpot> spotsSurprise = [];
  List<LineChartBarData> lineBarsData = [];
  late SideTitles leftTitles3;
  late SideTitles bottomTitles3;
  DateTime today = new DateTime.now();

  @override
  void initState() {
    super.initState();
    makeFilter();
    makeFilterEmotion();
  }

  List<DataEmotions> filterByLastDays(DateTime today, int days) {
    final sevenDaysAgo = today.subtract(Duration(days: days));
    return this
        .widget
        .data
        .where((object) => object.date.isAfter(sevenDaysAgo))
        .toList();
  }

  getDataChart() {
    angryVal = 0;
    disgustVal = 0;
    fearVal = 0;
    happyVal = 0;
    neutralVal = 0;
    sadVal = 0;
    surpriseVal = 0;

    spotsAngry = [];
    spotsDisgust = [];
    spotsFear = [];
    spotsHappy = [];
    spotsNeutral = [];
    spotsSad = [];
    spotsSurprise = [];

    double total = 0;
    for (var i = 0; i < data2.length; i++) {
      total += data2[i].count;
      // weeaks.add(data2[i].date.day);
      double val = data2[i].date.day.toDouble();
      if (selectedFilter == 'This Year') val = data2[i].date.month.toDouble();
      switch (data2[i].emotion) {
        case 'Angry':
          {
            spotsAngry.add(FlSpot(val, data2[i].count.toDouble()));
            angryVal += data2[i].count;
          }
        case 'Disgust':
          {
            spotsDisgust.add(FlSpot(val, data2[i].count.toDouble()));
            disgustVal += data2[i].count;
          }
        case 'Fear':
          {
            spotsFear.add(FlSpot(val, data2[i].count.toDouble()));
            fearVal += data2[i].count;
          }
        case 'Happy':
          {
            spotsHappy.add(FlSpot(val, data2[i].count.toDouble()));
            happyVal += data2[i].count;
          }
        case 'Neutral':
          {
            spotsNeutral.add(FlSpot(val, data2[i].count.toDouble()));
            neutralVal += data2[i].count;
          }
        case 'Sad':
          {
            spotsSad.add(FlSpot(val, data2[i].count.toDouble()));
            sadVal += data2[i].count;
          }
        case 'Surprise':
          {
            spotsSurprise.add(FlSpot(val, data2[i].count.toDouble()));
            surpriseVal += data2[i].count;
          }
        default:
          print("default");
      }
    }
    double maxY2 = angryVal;
    if (maxY < disgustVal)
      maxY = disgustVal;
    else if (maxY < fearVal)
      maxY = fearVal;
    else if (maxY < happyVal)
      maxY = happyVal;
    else if (maxY < neutralVal)
      maxY = neutralVal;
    else if (maxY < sadVal)
      maxY = sadVal;
    else if (maxY < surpriseVal) maxY = surpriseVal;
    setState(() {
      maxY = maxY2;
    });
    SideTitles leftTitles2 = SideTitles(
      getTitlesWidget: leftTitleWidgets,
      showTitles: true,
      interval: 1,
      reservedSize: 40,
    );
    SideTitles bottomTitles2 = SideTitles(
      showTitles: true,
      reservedSize: 32,
      interval: 1,
      getTitlesWidget: bottomTitleWidgets,
    );
    setState(() {
      bottomTitles3 = bottomTitles2;
    });
    leftTitles3 = leftTitles2;
    setState(() {
      leftTitles3 = leftTitles2;
    });
    leftTitles3 = SideTitles(
      getTitlesWidget: leftTitleWidgets,
      showTitles: true,
      interval: 1,
      reservedSize: 40,
    );
    // initGroupData();
    // showingSections();
  }

  void makeFilter() {
    print(selectedFilter);
    if (selectedFilter == 'All') {
      data2 = widget.data;
    } else if (selectedFilter == 'This Weak') {
      data2 = filterByLastDays(today, 7);
      mmaxX = 7;
    } else if (selectedFilter == 'This Month') {
      int day = today.day;
      mmaxX = 31 - (31 - day).toDouble();
      data2 = widget.data
          .where((object) =>
              object.date.month == today.month &&
              object.date.year == today.year)
          .toList();
    } else if (selectedFilter == 'This Year') {
      mmaxX = 12;
      data2 = widget.data
          .where((object) => object.date.year == today.year - 1)
          .toList();
    }
    getDataChart();
    // if (data2.length > 0) getDataChart();
    print(widget.data);
    print(data2);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButton<String>(
                value: selectedFilter,
                hint: const Text('Filter By'),
                onChanged: (newValue) {
                  setState(() {
                    selectedFilter = newValue;
                  });
                  makeFilter();
                },
                items:
                    filtersChart.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
              ),
              DropdownButton<String>(
                value: selectedEmotion,
                hint: Text('Emotion'),
                onChanged: (newValue) {
                  setState(() {
                    selectedEmotion = newValue;
                  });
                  makeFilterEmotion();
                },
                items: emotion.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ],
          ),
          AspectRatio(
            aspectRatio: 0.7,
            child: Stack(
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    // const SizedBox(
                    //   height: 37,
                    // ),
                    // const Text(
                    //   'between tow dates',
                    //   style: TextStyle(
                    //     color: AppColors.primary,
                    //     fontSize: 32,
                    //     fontWeight: FontWeight.bold,
                    //     letterSpacing: 2,
                    //   ),
                    //   textAlign: TextAlign.center,
                    // ),
                    // const SizedBox(
                    //   height: 37,
                    // ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(right: 16, left: 6),
                        child: LineChart(
                          sampleData1,
                          duration: const Duration(milliseconds: 250),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ],
            ),
          ),
          // LineChartSample1(),
        ],
      ),
    ));
  }

  LineChartData get sampleData1 => LineChartData(
        lineTouchData: lineTouchData1,
        gridData: gridData,
        titlesData: titlesData1,
        borderData: borderData,
        lineBarsData: lineBarsData,
        minX: 0,
        maxX: mmaxX,
        maxY: mmaxY,
        minY: 0,
      );

  LineTouchData get lineTouchData1 => LineTouchData(
        handleBuiltInTouches: true,
        touchTooltipData: LineTouchTooltipData(
          tooltipBgColor:
              const Color.fromARGB(255, 0, 164, 246).withOpacity(0.8),
        ),
      );

  FlTitlesData get titlesData1 => FlTitlesData(
        bottomTitles: AxisTitles(
          sideTitles: bottomTitles3,
        ),
        rightTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        topTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        leftTitles: AxisTitles(
          sideTitles: leftTitles3,
          // sideTitles: leftTitles(),
        ),
      );

  makeFilterEmotion() {
    List<LineChartBarData> lineBarsData3 = [];
    switch (selectedEmotion) {
      case 'All':
        lineBarsData3 = [
          lineChartBarDataAngry,
          lineChartBarDataDisgust,
          lineChartBarDataFear,
          lineChartBarDataHappy,
          lineChartBarDataNeutral,
          lineChartBarDataSad,
          lineChartBarDataSurprise,
        ];
      case 'Angry':
        lineBarsData3 = [
          lineChartBarDataAngry,
        ];
      case 'Disgust':
        lineBarsData3 = [
          lineChartBarDataDisgust,
        ];
      case 'Fear':
        lineBarsData3 = [
          lineChartBarDataFear,
        ];
      case 'Happy':
        lineBarsData3 = [
          lineChartBarDataHappy,
        ];
      case 'Neutral':
        lineBarsData3 = [
          lineChartBarDataNeutral,
        ];
      case 'Sad':
        lineBarsData3 = [
          lineChartBarDataSad,
        ];
      case 'Surprise':
        lineBarsData3 = [
          lineChartBarDataSurprise,
        ];
    }
    setState(() {
      lineBarsData = lineBarsData3;
    });
  }

  List<LineChartBarData> get lineBarsData1 => [
        lineChartBarDataAngry,
        lineChartBarDataDisgust,
        lineChartBarDataFear,
        lineChartBarDataHappy,
        lineChartBarDataNeutral,
        lineChartBarDataSad,
        lineChartBarDataSurprise,
      ];

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 14,
    );
    String text;
    print(maxY);
    print(maxY);
    if (maxY < 15) {
      if (value == 1) {
        text = '1';
      } else if (value == 2) {
        text = '2';
      } else if (value == 3) {
        text = '3';
      } else if (value == 4) {
        text = '4';
      } else if (value == 5) {
        text = '5';
      } else if (value == 6) {
        text = '6';
      } else if (value == 7) {
        text = '7';
      } else if (value == 8) {
        text = '8';
      } else if (value == 9) {
        text = '9';
      } else if (value == 10) {
        text = '10';
      } else if (value == 11) {
        text = '11';
      } else if (value == 12) {
        text = '12';
      } else if (value == 13) {
        text = '13';
      } else if (value == 14) {
        text = '14';
      } else if (value == 15) {
        text = '15';
      } else {
        return Container();
      }
    } else if (maxY < 150) {
      if (value == 1) {
        text = '10';
      } else if (value == 2) {
        text = '20';
      } else if (value == 3) {
        text = '30';
      } else if (value == 4) {
        text = '40';
      } else if (value == 5) {
        text = '50';
      } else if (value == 6) {
        text = '60';
      } else if (value == 7) {
        text = '70';
      } else if (value == 8) {
        text = '80';
      } else if (value == 9) {
        text = '90';
      } else if (value == 10) {
        text = '100';
      } else if (value == 11) {
        text = '110';
      } else if (value == 12) {
        text = '120';
      } else if (value == 13) {
        text = '130';
      } else if (value == 14) {
        text = '140';
      } else if (value == 15) {
        text = '150';
      } else {
        return Container();
      }
    } else if (maxY < 1500) {
      if (value == 1) {
        text = '100';
      } else if (value == 2) {
        text = '200';
      } else if (value == 3) {
        text = '300';
      } else if (value == 4) {
        text = '400';
      } else if (value == 5) {
        text = '500';
      } else if (value == 6) {
        text = '600';
      } else if (value == 7) {
        text = '700';
      } else if (value == 8) {
        text = '800';
      } else if (value == 9) {
        text = '900';
      } else if (value == 10) {
        text = '1000';
      } else if (value == 11) {
        text = '1100';
      } else if (value == 12) {
        text = '1200';
      } else if (value == 13) {
        text = '1300';
      } else if (value == 14) {
        text = '1400';
      } else if (value == 15) {
        text = '1500';
      } else {
        return Container();
      }
    } else {
      return Container();
    }
    print(text);
    return Text(text, style: style, textAlign: TextAlign.center);
  }

  SideTitles leftTitles() => SideTitles(
        getTitlesWidget: leftTitleWidgets,
        showTitles: true,
        interval: 1,
        reservedSize: 40,
      );

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    var style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: selectedFilter != "This Month" ? 12 : 16,
    );
    Widget text = Container();
    if (selectedFilter == "This Month") {
      text = days.contains(value.toInt()) && today.day >= value.toInt()
          ? Text((value.toInt()).toString(), style: style)
          : Container();
    } else if (selectedFilter == "This Year") {
      text = months.contains(value.toInt())
          ? Text((value.toInt()).toString(), style: style)
          : Container();
    } else if (selectedFilter == "This Weak") {
      text = weeaks.contains(value.toInt())
          ? Text((value.toInt()).toString(), style: style)
          : Container();
    } else {
      text = Container();
    }
    // bottomTitleWidgets3 = SideTitleWidget(
    //   axisSide: meta.axisSide,
    //   space: 10,
    //   child: text,
    // );
    return SideTitleWidget(
      axisSide: meta.axisSide,
      space: 10,
      child: text,
    );
  }

  SideTitles get bottomTitles => SideTitles(
        showTitles: true,
        reservedSize: 32,
        interval: 1,
        getTitlesWidget: bottomTitleWidgets,
      );

  FlGridData get gridData => const FlGridData(show: false);

  FlBorderData get borderData => FlBorderData(
        show: true,
        border: Border(
          bottom:
              BorderSide(color: AppColors.primary.withOpacity(0.2), width: 4),
          left: const BorderSide(color: Colors.transparent),
          right: const BorderSide(color: Colors.transparent),
          top: const BorderSide(color: Colors.transparent),
        ),
      );

  LineChartBarData get lineChartBarDataAngry => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorGreen,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsAngry,
      );

  LineChartBarData get lineChartBarDataDisgust => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorYellow,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(
          show: false,
          color: AppColors.contentColorPink.withOpacity(0),
        ),
        spots: spotsDisgust,
      );

  LineChartBarData get lineChartBarDataFear => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorCyan,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsFear,
      );
  LineChartBarData get lineChartBarDataHappy => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorRed,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsHappy,
      );
  LineChartBarData get lineChartBarDataNeutral => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorPurple,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsNeutral,
      );

  LineChartBarData get lineChartBarDataSad => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorOrange,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsSad,
      );

  LineChartBarData get lineChartBarDataSurprise => LineChartBarData(
        isCurved: true,
        color: AppColors.contentColorPink,
        barWidth: 8,
        isStrokeCapRound: true,
        dotData: const FlDotData(show: false),
        belowBarData: BarAreaData(show: false),
        spots: spotsSurprise,
      );
}
