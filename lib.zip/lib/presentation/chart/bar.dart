import 'dart:ffi';

import 'package:face_emotion/pages/dashboard.dart';
import 'package:face_emotion/presentation/resources/app_resources.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class Dashboard3 extends StatefulWidget {
  Dashboard3({
    Key? key,
    required this.tabIndex,
    required this.data,
  }) : super(key: key);
  List<DataEmotions> data = [];
  final int tabIndex;
  // Object data;

  @override
  _Dashboard3State createState() => _Dashboard3State();
}

class _Dashboard3State extends State<Dashboard3> {
  List<DataEmotions> data2 = [];
  int? selectedDay;
  late SideTitleWidget leftTitles;
  late SideTitleWidget bottomTitles;
  String? selectedMonth;
  bool isDayEnabled = false;
  bool isMonthEnabled = false;
  String? selectedFilter = 'All';
  String? selectedEmotion = 'All';
  final List<String> emotion = [
    'All',
    'Angry',
    'Disgust',
    'Fear',
    'Happy',
    'Neutral',
    'Sad',
    'Surprise',
  ];
  final List<int> days = List<int>.generate(31, (index) => index + 1);
  final List<String> months = [
    // 'all month',
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  final List<String> filtersChart = [
    'All',
    'Today',
    'This Weak',
    'This Month',
    'This Year',
    'Day Of Month',
    'Month Of Year',
  ];
  final double width = 7;
  final Color leftBarColor = AppColors.contentColorYellow;
  final Color avgColor = AppColors.contentColorPurple;
  late List<BarChartGroupData> rawBarGroups;
  late List<BarChartGroupData> showingBarGroups;
  double maxY = 4;
  int touchedGroupIndex = -1;

  double angryVal = 0;
  double disgustVal = 0;
  double fearVal = 0;
  double happyVal = 0;
  double neutralVal = 0;
  double sadVal = 0;
  double surpriseVal = 0;

  Map<String, int> monthMap = {
    'January': 1,
    'February': 2,
    'March': 3,
    'April': 4,
    'May': 5,
    'June': 6,
    'July': 7,
    'August': 8,
    'September': 9,
    'October': 10,
    'November': 11,
    'December': 12,
  };

  List<DataEmotions> filterByLast7Days(DateTime today) {
    final sevenDaysAgo = today.subtract(Duration(days: 7));
    return this
        .widget
        .data
        .where((object) => object.date.isAfter(sevenDaysAgo))
        .toList();
  }

  getDataChart() {
    angryVal = 0;
    disgustVal = 0;
    fearVal = 0;
    happyVal = 0;
    neutralVal = 0;
    sadVal = 0;
    surpriseVal = 0;

    double total = 0;
    for (var i = 0; i < data2.length; i++) {
      total += data2[i].count;
      switch (data2[i].emotion) {
        case 'Angry':
          angryVal += data2[i].count;
        case 'Disgust':
          disgustVal += data2[i].count;
        case 'Fear':
          fearVal += data2[i].count;
        case 'Happy':
          happyVal += data2[i].count;
        case 'Neutral':
          neutralVal += data2[i].count;
        case 'Sad':
          sadVal += data2[i].count;
        case 'Surprise':
          surpriseVal += data2[i].count;
        default:
          print("default");
      }
    }
    double maxY2 = angryVal;
    if (maxY < disgustVal)
      maxY = disgustVal;
    else if (maxY < fearVal)
      maxY = fearVal;
    else if (maxY < happyVal)
      maxY = happyVal;
    else if (maxY < neutralVal)
      maxY = neutralVal;
    else if (maxY < sadVal)
      maxY = sadVal;
    else if (maxY < surpriseVal) maxY = surpriseVal;
    setState(() {
      maxY = maxY2 *3;
    });
    initGroupData();
    // showingSections();
  }

  void makeFilter() {
    print(selectedFilter);
    DateTime today = new DateTime.now();
    if (selectedFilter == 'All') {
      data2 = widget.data;
    } else if (selectedFilter == "Day Of Month" && selectedDay != null) {
      data2 = widget.data
          .where((object) => object.date.day == selectedDay)
          .toList();
    } else if (selectedFilter == "Month Of Year" && selectedMonth != null) {
      var monthDay = monthMap[selectedMonth];
      print(monthDay);
      data2 =
          widget.data.where((object) => object.date.month == monthDay).toList();
    } else if (selectedFilter == 'Today') {
      data2 = widget.data
          .where((object) =>
              object.date.day == today.day &&
              object.date.month == today.month &&
              object.date.year == today.year)
          .toList();
    } else if (selectedFilter == 'This Weak') {
      data2 = filterByLast7Days(today);
    } else if (selectedFilter == 'This Month') {
      data2 = widget.data
          .where((object) =>
              object.date.month == today.month &&
              object.date.year == today.year)
          .toList();
    } else if (selectedFilter == 'This Year') {
      data2 = widget.data
          .where((object) => object.date.year == today.year)
          .toList();
    }
    getDataChart();
    // if (data2.length > 0) getDataChart();
    print(widget.data);
    print(data2);
  }

  BarChartGroupData makeGroupData(int x, double y1) {
    return BarChartGroupData(
      barsSpace: 5,
      x: x,
      barRods: [
        BarChartRodData(
          toY: y1,
          color: leftBarColor,
          width: width,
        ),
      ],
    );
  }

  initGroupData() {
    final angryGroup = makeGroupData(0, angryVal);
    final disgustGroup = makeGroupData(1, disgustVal);
    final fearGroup = makeGroupData(2, fearVal);
    final happyGroup = makeGroupData(3, happyVal);
    final neutralGroup = makeGroupData(4, neutralVal);
    final sadGroup = makeGroupData(5, sadVal);
    final surpriseGroup = makeGroupData(6, surpriseVal);
    List<BarChartGroupData> items = [];
    switch (selectedEmotion) {
      case 'All':
        items = [
          angryGroup,
          disgustGroup,
          fearGroup,
          happyGroup,
          neutralGroup,
          sadGroup,
          surpriseGroup,
        ];
      case 'Angry':
        items = [
          angryGroup,
        ];
      case 'Disgust':
        items = [
          disgustGroup,
        ];
      case 'Fear':
        items = [
          fearGroup,
        ];
      case 'Happy':
        items = [
          happyGroup,
        ];
      case 'Neutral':
        items = [
          neutralGroup,
        ];
      case 'Sad':
        items = [
          sadGroup,
        ];
      case 'Surprise':
        items = [
          surpriseGroup,
        ];
    }
    rawBarGroups = [
      angryGroup,
      disgustGroup,
      fearGroup,
      happyGroup,
      neutralGroup,
      sadGroup,
      surpriseGroup,
    ];
    showingBarGroups = items;
  }

  @override
  void initState() {
    super.initState();
    makeFilter();
    // initGroupData();
  }

  // void getLeftTitles(double value, TitleMeta meta) {
  Widget getLeftTitles(double value, TitleMeta meta) {
    const style = TextStyle(
      color: Color(0xff7589a2),
      fontWeight: FontWeight.bold,
      fontSize: 14,
    );
    String text;
    if (maxY < 100) {
      if (value == 1) {
        text = '1';
      } else if (value == 5) {
        text = '5';
      } else if (value == 10) {
        text = '10';
      } else if (value == 20) {
        text = '20';
      } else if (value == 30) {
        text = '30';
      } else if (value == 40) {
        text = '40';
      } else if (value == 50) {
        text = '50';
      } else if (value == 60) {
        text = '60';
      } else if (value == 70) {
        text = '70';
      } else if (value == 80) {
        text = '80';
      } else if (value == 90) {
        text = '90';
      }
      else {
        // text = '10';
        return Container();
      }
    }
    else if (maxY < 1000) {
      if (value == 100) {
        text = '100';
      } else if (value == 200) {
        text = '200';
      } else if (value == 300) {
        text = '300';
      } else if (value == 400) {
        text = '400';
      } else if (value == 500) {
        text = '500';
      } else if (value == 600) {
        text = '600';
      } else if (value == 700) {
        text = '700';
      } else if (value == 800) {
        text = '800';
      } else if (value == 900) {
        text = '900';
      }
      else {
        // text = '10';
        return Container();
      }
    }
    else if (maxY < 10000) {
      if (value == 1000) {
        text = '1k';
      } else if (value == 2000) {
        text = '2k';
      } else if (value == 3000) {
        text = '3k';
      } else if (value == 4000) {
        text = '4k';
      } else if (value == 5000) {
        text = '5k';
      } else if (value == 6000) {
        text = '6k';
      } else if (value == 7000) {
        text = '7k';
      } else if (value == 8000) {
        text = '8k';
      } else if (value == 9000) {
        text = '9k';
      }
      else {
        // text = '10';
        return Container();
      }
    }
    else if (maxY < 100000) {
      if (value == 10000) {
        text = '10k';
      } else if (value == 20000) {
        text = '20k';
      } else if (value == 30000) {
        text = '30k';
      } else if (value == 40000) {
        text = '40k';
      } else if (value == 50000) {
        text = '50k';
      } else if (value == 60000) {
        text = '60k';
      } else if (value == 70000) {
        text = '70k';
      } else if (value == 80000) {
        text = '80k';
      } else if (value == 90000) {
        text = '90k';
      }
      else {
        // text = '10';
        return Container();
      }
    }
    else if (maxY < 1000000) {
      if (value == 100000) {
        text = '100k';
      } else if (value == 200000) {
        text = '200k';
      } else if (value == 300000) {
        text = '300k';
      } else if (value == 400000) {
        text = '400k';
      } else if (value == 500000) {
        text = '500k';
      } else if (value == 600000) {
        text = '600k';
      } else if (value == 700000) {
        text = '700k';
      } else if (value == 800000) {
        text = '800k';
      } else if (value == 900000) {
        text = '900k';
      }
      else {
        // text = '10';
        return Container();
      }
    }
    else if (maxY < 10000000) {
      if (value == 1000000) {
        text = '1m';
      } else if (value == 2000000) {
        text = '2m';
      } else if (value == 3000000) {
        text = '3m';
      } else if (value == 4000000) {
        text = '4m';
      } else if (value == 5000000) {
        text = '5m';
      } else if (value == 6000000) {
        text = '6m';
      } else if (value == 7000000) {
        text = '7m';
      } else if (value == 8000000) {
        text = '8m';
      } else if (value == 9000000) {
        text = '9m';
      } else if (value == 10000000) {
        text = '10m';
      } else if (value == 20000000) {
        text = '20m';
      } else if (value == 30000000) {
        text = '30m';
      } else if (value == 40000000) {
        text = '40m';
      } else if (value == 50000000) {
        text = '50m';
      } else if (value == 60000000) {
        text = '60m';
      } else if (value == 70000000) {
        text = '70m';
      } else if (value == 80000000) {
        text = '80m';
      } else if (value == 90000000) {
        text = '90m';
      } else {
        // text = '10';
        return Container();
      }
    }
    else {
      // text = '10';
      return Container();
    }
    // SideTitleWidget leftTitles2 = SideTitleWidget(
    //   axisSide: meta.axisSide,
    //   space: 0,
    //   child: Text(text, style: style),
    // );
    // setState(() {
    //   leftTitles = leftTitles2;
    // });
    return SideTitleWidget(
      axisSide: meta.axisSide,
      space: 0,
      child: Text(text, style: style),
    );
  }

  Widget getBottomTitles(double value, TitleMeta meta) {
    // void getBottomTitles(double value, TitleMeta meta) {
    final titles = <String>[
      'Angry',
      'Disgust',
      'Fear',
      'Happy',
      'Neutral',
      'Sad',
      'Surprise'
    ];

    final Widget text = Text(
      titles[value.toInt()],
      style: const TextStyle(
        color: Color(0xff7589a2),
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
    );

    // SideTitleWidget bottomTitles2 = SideTitleWidget(
    //   axisSide: meta.axisSide,
    //   space: 16, //margin top
    //   child: text,
    // );
    // setState(() {
    //   bottomTitles = bottomTitles2;
    // });

    return SideTitleWidget(
      axisSide: meta.axisSide,
      space: 16, //margin top
      child: text,
    );
  }

  // BarChartGroupData makeGroupData(int x, double y1, double y2) {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButton<String>(
                value: selectedEmotion,
                hint: Text('Emotion'),
                onChanged: (newValue) {
                  setState(() {
                    selectedEmotion = newValue;
                  });
                  initGroupData();
                },
                items: emotion.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              DropdownButton<String>(
                value: selectedFilter,
                hint: const Text('Filter By'),
                onChanged: (newValue) {
                  setState(() {
                    selectedFilter = newValue;
                  });
                  if (newValue != 'Day Of Month') {
                    selectedDay = null;
                    isDayEnabled = false;
                  } else {
                    isDayEnabled = true;
                  }
                  if (newValue != 'Month Of Year') {
                    selectedMonth = null;
                    isMonthEnabled = false;
                  } else {
                    isMonthEnabled = true;
                  }
                  makeFilter();
                },
                items:
                    filtersChart.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
              ),
              DropdownButton<int>(
                value: selectedDay,
                hint: const Text('Day'),
                onChanged: (newValue) {
                  setState(() {
                    selectedDay = newValue;
                  });
                  makeFilter();
                },
                items: isDayEnabled
                    ? days.map<DropdownMenuItem<int>>((int value) {
                        return DropdownMenuItem<int>(
                          value: value,
                          child: Text(value.toString()),
                        );
                      }).toList()
                    : [],
              ),
              SizedBox(width: 50.0),
              DropdownButton<String>(
                value: selectedMonth,
                hint: Text('Month'),
                onChanged: (newValue) {
                  setState(() {
                    selectedMonth = newValue;
                  });
                  makeFilter();
                },
                items: isMonthEnabled
                    ? months.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList()
                    : [],
              ),
            ],
          ),
          AspectRatio(
            aspectRatio: 0.6,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Expanded(
                    child: BarChart(
                      BarChartData(
                        maxY: maxY,
                        barTouchData: BarTouchData(
                          touchTooltipData: BarTouchTooltipData(
                            tooltipBgColor: Colors.grey,
                            getTooltipItem: (a, b, c, d) => null,
                          ),
                          touchCallback: (FlTouchEvent event, response) {
                            if (response == null || response.spot == null) {
                              setState(() {
                                touchedGroupIndex = -1;
                                showingBarGroups = List.of(rawBarGroups);
                              });
                              return;
                            }

                            touchedGroupIndex =
                                response.spot!.touchedBarGroupIndex;
                            setState(() {
                              if (!event.isInterestedForInteractions) {
                                touchedGroupIndex = -1;
                                showingBarGroups = List.of(rawBarGroups);
                                return;
                              }
                              showingBarGroups = List.of(rawBarGroups);
                              if (touchedGroupIndex != -1) {
                                var sum = 0.0;
                                for (final rod
                                    in showingBarGroups[touchedGroupIndex]
                                        .barRods) {
                                  sum += rod.toY;
                                }
                                final avg = sum /
                                    showingBarGroups[touchedGroupIndex]
                                        .barRods
                                        .length;

                                showingBarGroups[touchedGroupIndex] =
                                    showingBarGroups[touchedGroupIndex]
                                        .copyWith(
                                  barRods: showingBarGroups[touchedGroupIndex]
                                      .barRods
                                      .map((rod) {
                                    return rod.copyWith(
                                        toY: avg, color: avgColor);
                                  }).toList(),
                                );
                              }
                            });
                          },
                        ),
                        titlesData: FlTitlesData(
                          show: true,
                          rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                          topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: getBottomTitles,
                              reservedSize: 70,
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 20,
                              interval: 0.5,
                              getTitlesWidget: getLeftTitles,
                            ),
                          ),
                        ),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        barGroups: showingBarGroups,
                        gridData: const FlGridData(show: true),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
          // BarChartSample2(),
        ],
      ),
    ));
  }
}
