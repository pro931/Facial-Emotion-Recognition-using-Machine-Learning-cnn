import 'package:face_emotion/pages/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:face_emotion/presentation/resources/app_resources.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:face_emotion/presentation/widgets/indicator.dart';

class Dashboard1 extends StatefulWidget {
  Dashboard1({
    Key? key,
    required this.tabIndex,
    required this.data,
  }) : super(key: key);

  final int tabIndex;
  // Object data;
  List<DataEmotions> data;

  @override
  _Dashboard1State createState() => _Dashboard1State();
}

class _Dashboard1State extends State<Dashboard1> {
  List<DataEmotions> data2 = [];
  // DateTime date;
  int? selectedDay;
  String? selectedMonth;
  bool isDayEnabled = false;
  bool isMonthEnabled = false;
  String? selectedFilter = 'All';
  DateTime selectedDate = DateTime.now();
  final List<int> days = List<int>.generate(31, (index) => index + 1);
  final List<String> months = [
    // 'all month',
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  final List<String> filtersChart = [
    'All',
    'Today',
    'This Weak',
    'This Month',
    'This Year',
    'Day Of Month',
    'Month Of Year',
    // 'Date',
  ];
  // final Function(int) onTabTap;

  double angryValue = 0;
  double disgustValue = 0;
  double fearValue = 0;
  double happyValue = 0;
  double neutralValue = 0;
  double sadValue = 0;
  double surpriseValue = 0;

  double angryVal = 0;
  double disgustVal = 0;
  double fearVal = 0;
  double happyVal = 0;
  double neutralVal = 0;
  double sadVal = 0;
  double surpriseVal = 0;
  // PieChartData _chartData;
  // const MyTabChild({Key? key, required this.tabIndex, required this.data, , required this.onTabTap})
  List<PieChartSectionData> showingSections2 = [];

  Map<String, int> monthMap = {
    'January': 1,
    'February': 2,
    'March': 3,
    'April': 4,
    'May': 5,
    'June': 6,
    'July': 7,
    'August': 8,
    'September': 9,
    'October': 10,
    'November': 11,
    'December': 12,
  };

  List<DataEmotions> filterByLast7Days(DateTime today) {
    final sevenDaysAgo = today.subtract(Duration(days: 7));
    return this.widget.data.where((object) => object.date.isAfter(sevenDaysAgo)).toList();
  }

  void makeFilter() {
    print(selectedFilter);
    DateTime today = new DateTime.now();
    if (selectedFilter == 'All') {
      data2 = widget.data;
    } else if (selectedFilter == "Day Of Month" && selectedDay != null) {
      data2 = widget.data
          .where((object) => object.date.day == selectedDay)
          .toList();
    } else if (selectedFilter == "Month Of Year" && selectedMonth != null) {
      var monthDay = monthMap[selectedMonth];
      print(monthDay);
      data2 =
          widget.data.where((object) => object.date.month == monthDay).toList();
    } else if (selectedFilter == 'Today') {
      data2 = widget.data
          .where((object) =>
              object.date.day == today.day &&
              object.date.month == today.month &&
              object.date.year == today.year)
          .toList();
    } else if (selectedFilter == 'This Weak') {
      data2 = filterByLast7Days(today);
    } else if (selectedFilter == 'This Month') {
      data2 = widget.data
          .where((object) =>
              object.date.month == today.month &&
              object.date.year == today.year)
          .toList();
    } else if (selectedFilter == 'This Year') {
      data2 = widget.data
          .where((object) => object.date.year == today.year)
          .toList();
    }
    getDataChart();
    print(widget.data);
    print(data2);
  }

  getDataChart() {
    angryVal = 0;
    disgustVal = 0;
    fearVal = 0;
    happyVal = 0;
    neutralVal = 0;
    sadVal = 0;
    surpriseVal = 0;

    double total = 0;
    for (var i = 0; i < data2.length; i++) {
      total += data2[i].count;
      switch (data2[i].emotion) {
        case 'Angry':
          angryVal += data2[i].count;
        case 'Disgust':
          disgustVal += data2[i].count;
        case 'Fear':
          fearVal += data2[i].count;
        case 'Happy':
          happyVal += data2[i].count;
        case 'Neutral':
          neutralVal += data2[i].count;
        case 'Sad':
          sadVal += data2[i].count;
        case 'Surprise':
          surpriseVal += data2[i].count;
        default:
          print("default");
      }
    }

    setState(() {
      angryValue = angryVal != 0 ? (angryVal / total) * 100 : 0;
    });
    setState(() {
      disgustValue = disgustVal != 0 ? (disgustVal / total) * 100 : 0;
    });
    setState(() {
      fearValue = fearVal != 0 ? (fearVal / total) * 100 : 0;
    });
    setState(() {
      happyValue = happyVal != 0 ? (happyVal / total) * 100 : 0;
    });
    setState(() {
      neutralValue = neutralVal != 0 ? (neutralVal / total) * 100 : 0;
    });
    setState(() {
      sadValue = sadVal != 0 ? (sadVal / total) * 100 : 0;
    });
    setState(() {
      surpriseValue = surpriseVal != 0 ? (surpriseVal / total) * 100 : 0;
    });
    showingSections();
  }

  int touchedIndex = -1;

  @override
  void initState() {
    super.initState();
    this.makeFilter();
    print(widget.data);
    print(data2);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButton<String>(
                value: selectedFilter,
                hint: const Text('Filter By'),
                onChanged: (newValue) {
                  setState(() {
                    selectedFilter = newValue;
                  });
                  if (newValue != 'Day Of Month') {
                    selectedDay = null;
                    isDayEnabled = false;
                  } else {
                    isDayEnabled = true;
                  }
                  if (newValue != 'Month Of Year') {
                    selectedMonth = null;
                    isMonthEnabled = false;
                  } else {
                    isMonthEnabled = true;
                  }
                  makeFilter();
                },
                items:
                    filtersChart.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
              ),
              DropdownButton<int>(
                value: selectedDay,
                hint: const Text('Day'),
                onChanged: (newValue) {
                  setState(() {
                    selectedDay = newValue;
                  });
                  makeFilter();
                },
                items: isDayEnabled
                    ? days.map<DropdownMenuItem<int>>((int value) {
                        return DropdownMenuItem<int>(
                          value: value,
                          child: Text(value.toString()),
                        );
                      }).toList()
                    : [],
              ),
              SizedBox(width: 50.0),
              DropdownButton<String>(
                value: selectedMonth,
                hint: Text('Month'),
                onChanged: (newValue) {
                  setState(() {
                    selectedMonth = newValue;
                  });
                  makeFilter();
                },
                items: isMonthEnabled
                    ? months.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList()
                    : [],
              ),
            ],
          ),
          AspectRatio(
            aspectRatio: 0.8,
            child: PieChart(
              PieChartData(
                pieTouchData: PieTouchData(
                  touchCallback: (FlTouchEvent event, pieTouchResponse) {
                    setState(() {
                      if (!event.isInterestedForInteractions ||
                          pieTouchResponse == null ||
                          pieTouchResponse.touchedSection == null) {
                        touchedIndex = -1;
                        return;
                      }
                      touchedIndex =
                          pieTouchResponse.touchedSection!.touchedSectionIndex;
                    });
                  },
                ),
                sectionsSpace: 1,
                centerSpaceRadius: 100,
                startDegreeOffset: 120,
                sections: showingSections2,
                // sections: showingSections(),
              ),
              swapAnimationCurve: Curves.bounceInOut,
            ),
          ),
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(width: 10.0),
              Indicator(
                color: AppColors.contentColorBlue,
                text: 'Angry',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 20.0),
              Indicator(
                color: AppColors.contentColorRed,
                text: 'Disgust',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 20.0),
              Indicator(
                color: AppColors.contentColorPink,
                text: 'Fear',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 20.0),
              Indicator(
                color: AppColors.contentColorOrange,
                text: 'Happy',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 20.0),
            ],
          ),
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(width: 20.0),
              Indicator(
                color: AppColors.contentColorYellow,
                text: 'Neutral',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 30.0),
              Indicator(
                color: AppColors.contentColorPurple,
                text: 'Sad',
                isSquare: true,
                size: 30,
              ),
              SizedBox(width: 30.0),
              Indicator(
                color: AppColors.contentColorGreen,
                text: 'Surprise',
                isSquare: true,
                size: 30,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // List<PieChartSectionData> showingSections() {
  void showingSections() {
    List<PieChartSectionData> showingSections3 = List.generate(7, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      const shadows = [Shadow(color: Colors.black, blurRadius: 2)];
      switch (i) {
        case 0:
          // if(angryVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorBlue,
            value: angryValue,
            title: '${angryValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 1:
          // if(disgustVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorRed,
            value: disgustValue,
            title: '${disgustValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 2:
          // if(fearVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorPink,
            value: fearValue,
            title: '${fearValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 3:
          // if(happyVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorOrange,
            value: happyValue,
            title: '${happyValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 4:
          // if(neutralVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorYellow,
            value: neutralValue,
            title: '${neutralValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 5:
          // if(sadVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorPurple,
            value: sadValue,
            title: '${sadValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        case 6:
          // if(surpriseVal != 0)
          return PieChartSectionData(
            color: AppColors.contentColorGreen,
            value: surpriseValue,
            title: '${surpriseValue.toStringAsFixed(2)}%',
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: AppColors.mainTextColor1,
              shadows: shadows,
            ),
          );
        default:
          throw Error();
      }
    });
    setState(() {
      showingSections2 = showingSections3;
    });
  }
}
