import 'package:flutter/material.dart';
import 'package:face_emotion/pages/login.dart';
import 'package:face_emotion/pages/signup.dart';
import 'package:face_emotion/pages/welcome.dart';
import 'package:face_emotion/pages/dashboard.dart';
import 'package:face_emotion/pages/realtime.dart';
import 'package:face_emotion/pages/photo_from_camera.dart';
import 'package:face_emotion/pages/photo_from_gallery.dart';
import 'package:face_emotion/pages/aboutUs.dart';
import 'package:camera/camera.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cameras = await availableCameras();
  final firstCamera = cameras.first;

  runApp(
     MyApp(camera: firstCamera,)
  );
}

class MyApp extends StatelessWidget {
   MyApp({
    super.key,
    required this.camera,
  });
  final CameraDescription camera;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowMaterialGrid: false,
      title: 'Emotion Face',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      routes: {
        '/': (context) => const Welcome(),
        "/login": (context) => const LoginForm(),
        "/signup": (context) => const Signup(),
        "/dashboard": (context) => Dashboard(),
        "/take-photo": (context) => TakePictureScreen(camera: camera,),
        "/select-photo": (context) => const EmotionFromPhotoGallery(),
        "/realtime": (context) => RealtimeScreen(),
        "/about-us": (context) => AboutUs(),
      },
    );
  }
}
